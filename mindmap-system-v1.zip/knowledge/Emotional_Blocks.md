# Emotional Blocks
